<?php

// Joyee Bridge – local server configuration.
// Tento subor necommitovat do GitHubu.
// Musi zostat iba na serveri.

$joyee_bridge_enabled = true;

// Verejny bridge kluc pre Joyee.
// Musi byt iny ako hlavny API token.
// Po prvom teste ho odporucam vymenit.
$joyee_bridge_key = 'ff79976d7566286f32cbd41086087ea9ac61057044b006616e62291f3d4775ae';

// Skutocny API token z api.config.php.
// Tento token sa neposiela do URL a zostava iba na serveri.
$joyee_api_token = '4033739f0df688686cfe27873b2df4e4e071196b0210e0450c5cf9edf27942b2';

// Samostatny root pre Joyee bridge (oddeleny od Mirko workspace).
$joyee_bridge_root_path = __DIR__ . '/Joyee';

// Volitelna konfiguracia API tokenu pre Joyee bridge.
// root_path je vynutene nastavovany na $joyee_bridge_root_path.
$joyee_api_token_config = array(
    'label' => 'Joyee Bridge API',
    'role' => 'admin',
    'capabilities' => array(
        'list' => true,
        'stat' => true,
        'read' => true,
        'write' => true,
        'mkdir' => true,
        'delete' => true,
        'rename' => true,
        'move' => true,
        'copy' => true,
    ),
);

// Povolene akcie cez bridge.
// Na prvy test mozes nechat iba ping/list/stat/read.
// Plne prava zapni az po overeni.
$joyee_bridge_allowed_actions = array(
    'ping',
    'list',
    'stat',
    'read',
    'write',
    'mkdir',
    'rename',
    'move',
    'copy',
    'delete',
);
