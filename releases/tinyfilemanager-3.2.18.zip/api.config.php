<?php
// Tiny File Manager API – local server configuration.
// Tento súbor necommitovať do GitHubu.

$api_enabled = true;

$api_tokens = array(
    '4033739f0df688686cfe27873b2df4e4e071196b0210e0450c5cf9edf27942b2' => array(
        'label' => 'Joyee API',
        'role' => 'admin',
        'root_path' => isset($root_path) ? $root_path : __DIR__,
        'capabilities' => array(
            'list' => true,
            'stat' => true,
            'read' => true,
            'write' => true,
            'mkdir' => true,
            'delete' => true,
            'rename' => true,
            'move' => true,
            'copy' => true,
            'assistant' => true,
        ),
    ),
);

$assistant_enabled = true;
$assistant_openai_api_key = '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';
$assistant_root_path = __DIR__ . '/Joyee';
$assistant_openai_model = 'gpt-4o-mini';
$assistant_openai_base_url = 'https://api.openai.com/v1';
$assistant_openai_temperature = 0.2;
$assistant_max_files = 8;
$assistant_max_file_bytes = 200000;
$assistant_allowed_extensions = array('php', 'md', 'txt', 'json', 'js', 'css', 'html', 'xml', 'yml', 'yaml', 'ini', 'sh', 'sql', 'env');
$assistant_system_prompt = 'You are a careful coding assistant for Tiny File Manager. Work only with the files provided in context, explain changes clearly, and avoid assuming access to anything outside the configured project root.';