<?php
/**
 * TinyFileManager - Legacy Upload Handler
 * Incremental extraction that preserves the existing upload behavior.
 */

class TFM_LegacyUploadHandler {
    private $root_path;
    private $current_path;
    private $max_url_upload_bytes;

    public function __construct($root_path, $current_path = '') {
        $this->root_path = rtrim((string) $root_path, '/\\');
        $this->current_path = (string) $current_path;

        $maxUploadMb = defined('MAX_UPLOAD_SIZE') ? (float) MAX_UPLOAD_SIZE : 128.0;
        if ($maxUploadMb <= 0) {
            $maxUploadMb = 128.0;
        }
        $this->max_url_upload_bytes = (int) round($maxUploadMb * 1024 * 1024);
    }

    /**
     * Handle upload request and echo legacy JSON response.
     * @param array $files
     * @param array $post
     * @param array $request
     * @return void
     */
    public function handle($files, $post, $request) {
        if (isset($post['token'])) {
            if (!verifyToken($post['token'])) {
                echo json_encode(array('status' => 'error', 'info' => 'Invalid Token.'));
                exit();
            }
        } else {
            echo json_encode(array('status' => 'error', 'info' => 'Token Missing.'));
            exit();
        }

        $chunkIndex = isset($post['dzchunkindex']) ? $post['dzchunkindex'] : null;
        $chunkTotal = isset($post['dztotalchunkcount']) ? $post['dztotalchunkcount'] : null;
        $requestedUploadDir = fm_clean_path(isset($request['upload_dir']) ? (string) $request['upload_dir'] : $this->current_path);
        $rawFullPathInput = isset($request['fullpath']) ? (string) $request['fullpath'] : '';

        $f = $files;
        $ds = DIRECTORY_SEPARATOR;

        $allowed = (FM_UPLOAD_EXTENSION) ? explode(',', FM_UPLOAD_EXTENSION) : false;
        $allowed = is_array($allowed) ? array_map('strtolower', array_map('trim', $allowed)) : false;
        $response = array(
            'status' => 'error',
            'info'   => 'Oops! Try again'
        );

        $filename = isset($f['file']['name']) ? (string) $f['file']['name'] : '';
        $tmp_name = isset($f['file']['tmp_name']) ? (string) $f['file']['tmp_name'] : '';

        if ($filename === '' || !isset($f['file']['tmp_name'])) {
            $response = array(
                'status' => 'error',
                'info'   => 'No file received for upload.',
            );
            echo json_encode($response);
            exit();
        }

        $safeRelativePath = $this->sanitizeUploadRelativePath($rawFullPathInput !== '' ? $rawFullPathInput : $filename);
        if ($safeRelativePath === '') {
            $response = array(
                'status' => 'error',
                'info'   => 'Invalid upload path. Absolute paths and traversal are not allowed.',
            );
            echo json_encode($response);
            exit();
        }

        $safeFileName = basename($safeRelativePath);
        if (!fm_isvalid_filename($safeFileName)) {
            $response = array(
                'status' => 'error',
                'info'   => 'Invalid File name!',
            );
            echo json_encode($response);
            exit();
        }

        $ext = pathinfo($safeFileName, PATHINFO_FILENAME) != '' ? strtolower(pathinfo($safeFileName, PATHINFO_EXTENSION)) : '';
        $isFileAllowed = ($allowed) ? in_array($ext, $allowed, true) : true;
        if (!$isFileAllowed) {
            $response = array(
                'status' => 'error',
                'info'   => 'File extension is not allowed.',
            );
            echo json_encode($response);
            exit();
        }

        $targetPath = $this->resolveUploadBasePath($requestedUploadDir);
        if ($targetPath === null) {
            $response = array(
                'status' => 'error',
                'info'   => 'Upload target path is not allowed.',
            );
            echo json_encode($response);
            exit();
        }

        if (function_exists('fm_validate_mime_type') && !fm_validate_mime_type($tmp_name)) {
            if (class_exists('AuditLogger')) {
                $audit = new AuditLogger();
                $audit->log('upload_rejected', $_SESSION[FM_SESSION_ID]['logged'] ?? 'unknown', "Dangerous MIME type: $safeFileName");
            }
            $response = array(
                'status' => 'error',
                'info'   => 'Dangerous file MIME type detected!',
            );
            echo json_encode($response);
            @unlink($tmp_name);
            exit();
        }

        if (function_exists('fm_validate_magic_bytes') && !fm_validate_magic_bytes($tmp_name, $ext)) {
            if (class_exists('AuditLogger')) {
                $audit = new AuditLogger();
                $audit->log('upload_rejected', $_SESSION[FM_SESSION_ID]['logged'] ?? 'unknown', "Invalid magic bytes: $safeFileName (ext: $ext)");
            }
            $response = array(
                'status' => 'error',
                'info'   => 'File signature does not match extension!',
            );
            echo json_encode($response);
            @unlink($tmp_name);
            exit();
        }

        $targetPath = rtrim($targetPath, '/\\') . $ds;
        if (is_writable($targetPath)) {
            $fullPath = rtrim($targetPath, '/\\') . '/' . $safeRelativePath;
            $fullPath = str_replace('\\', '/', $fullPath);
            $fullPath = preg_replace('#/+#', '/', $fullPath);

            if (!fm_is_path_inside($fullPath, rtrim($targetPath, '/\\'))) {
                $response = array(
                    'status' => 'error',
                    'info'   => 'Resolved upload path is outside allowed directory.',
                );
                echo json_encode($response);
                exit();
            }

            $folder = substr($fullPath, 0, strrpos($fullPath, '/'));
            if (!is_dir($folder)) {
                $old = umask(0);
                if (!@mkdir($folder, 0777, true) && !is_dir($folder)) {
                    $response = array(
                        'status' => 'error',
                        'info'   => 'Unable to create upload destination folder.',
                    );
                    echo json_encode($response);
                    exit();
                }
                umask($old);
            }

            if (empty($f['file']['error']) && !empty($tmp_name) && $tmp_name != 'none') {
                if ($chunkTotal) {
                    $out = @fopen("{$fullPath}.part", $chunkIndex == 0 ? 'wb' : 'ab');
                    if ($out) {
                        $in = @fopen($tmp_name, 'rb');
                        if ($in) {
                            if (PHP_VERSION_ID < 80009) {
                                do {
                                    for (;;) {
                                        $buff = fread($in, 4096);
                                        if ($buff === false || $buff === '') {
                                            break;
                                        }
                                        fwrite($out, $buff);
                                    }
                                } while (!feof($in));
                            } else {
                                stream_copy_to_stream($in, $out);
                            }
                            $response = array(
                                'status' => 'success',
                                'info'   => 'file upload successful'
                            );
                        } else {
                            $response = array(
                                'status' => 'error',
                                'info'   => 'Failed to open input stream.',
                                'errorDetails' => error_get_last()
                            );
                        }
                        @fclose($in);
                        @fclose($out);
                        @unlink($tmp_name);
                    } else {
                        $response = array(
                            'status' => 'error',
                            'info'   => 'Failed to open output stream.'
                        );
                    }

                    if ($chunkIndex == $chunkTotal - 1) {
                        if (file_exists($fullPath)) {
                            $ext_1 = $ext ? '.' . $ext : '';
                            $relativeDir = dirname($safeRelativePath);
                            if ($relativeDir === '.' || $relativeDir === '/') {
                                $relativeDir = '';
                            }
                            $collisionName = basename($safeFileName, $ext_1) . '_' . date('ymdHis') . $ext_1;
                            $fullPathTarget = rtrim($targetPath, '/\\')
                                . ($relativeDir !== '' ? '/' . $relativeDir : '')
                                . '/' . $collisionName;
                            $fullPathTarget = str_replace('\\', '/', $fullPathTarget);
                            $fullPathTarget = preg_replace('#/+#', '/', $fullPathTarget);
                        } else {
                            $fullPathTarget = $fullPath;
                        }
                        if (!fm_is_path_inside($fullPathTarget, rtrim($targetPath, '/\\'))) {
                            $response = array(
                                'status' => 'error',
                                'info'   => 'Resolved upload path is outside allowed directory.',
                            );
                        } elseif (rename("{$fullPath}.part", $fullPathTarget)) {
                            if (function_exists('fm_owner_meta_touch')) {
                                fm_owner_meta_touch($fullPathTarget, 'upload');
                            }
                        }
                    }
                } else if (move_uploaded_file($tmp_name, $fullPath)) {
                    if (file_exists($fullPath)) {
                        if (function_exists('fm_owner_meta_touch')) {
                            fm_owner_meta_touch($fullPath, 'upload');
                        }
                        $response = array(
                            'status' => 'success',
                            'info'   => 'file upload successful'
                        );
                    } else {
                        $response = array(
                            'status' => 'error',
                            'info'   => 'Could not persist uploaded file to destination.'
                        );
                    }
                } else {
                    $response = array(
                        'status' => 'error',
                        'info'   => 'Error while moving uploaded file to destination.',
                    );
                }
            }

            if (!empty($f['file']['error'])) {
                $response = array(
                    'status' => 'error',
                    'info'   => 'Upload failed with PHP upload error code: ' . (int) $f['file']['error'],
                );
            }
        } else {
            $response = array(
                'status' => 'error',
                'info'   => 'The specified folder for upload is not writable.'
            );
        }

        echo json_encode($response);
        exit();
    }

    /**
     * Handle upload-via-URL request and echo legacy JSON response.
     * @param array $request
     * @return void
     */
    public function handleUrlUpload($request) {
        $url = isset($request['uploadurl']) ? trim((string) stripslashes((string) $request['uploadurl'])) : '';
        $uploadDir = isset($request['upload_dir']) ? fm_clean_path((string) $request['upload_dir']) : $this->current_path;

        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Invalid URL parameter.')));
            exit();
        }

        if (!$this->isAllowedRemoteUrl($url)) {
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'URL is not allowed.')));
            exit();
        }

        $targetBase = $this->resolveUploadBasePath($uploadDir);
        if ($targetBase === null || !is_dir($targetBase) || !is_writable($targetBase)) {
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Upload target path is not writable.')));
            exit();
        }

        $tempFile = tempnam(sys_get_temp_dir(), 'url-upload-');
        if ($tempFile === false) {
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Cannot create temporary file for download.')));
            exit();
        }

        $downloadResult = $this->downloadRemoteFile($url, $tempFile, $this->max_url_upload_bytes);
        if (!$downloadResult['success']) {
            @unlink($tempFile);
            $this->emitUrlUploadEvent(array('fail' => array('message' => $downloadResult['message'])));
            exit();
        }

        $resolvedName = $this->resolveUploadUrlFileName($url, $downloadResult['headers']);
        $sanitizedName = $this->sanitizeUploadFileName($resolvedName);
        if ($sanitizedName === '') {
            @unlink($tempFile);
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Cannot determine target file name from URL.')));
            exit();
        }

        $allowed = (FM_UPLOAD_EXTENSION) ? explode(',', FM_UPLOAD_EXTENSION) : false;
        $allowed = is_array($allowed) ? array_map('strtolower', array_map('trim', $allowed)) : false;
        $currentExt = strtolower(pathinfo($sanitizedName, PATHINFO_EXTENSION));
        if ($allowed) {
            if ($currentExt === '' || !in_array($currentExt, $allowed, true)) {
                $guessedExt = $this->guessExtensionFromContentType($downloadResult['contentType']);
                if ($guessedExt !== '' && in_array($guessedExt, $allowed, true)) {
                    $sanitizedName .= '.' . $guessedExt;
                    $currentExt = $guessedExt;
                }
            }
            if ($currentExt === '' || !in_array($currentExt, $allowed, true)) {
                @unlink($tempFile);
                $this->emitUrlUploadEvent(array('fail' => array('message' => 'File extension is not allowed.')));
                exit();
            }
        }

        if (function_exists('fm_validate_mime_type') && !fm_validate_mime_type($tempFile)) {
            @unlink($tempFile);
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Dangerous file MIME type detected.')));
            exit();
        }

        $validatedExt = strtolower(pathinfo($sanitizedName, PATHINFO_EXTENSION));
        if (function_exists('fm_validate_magic_bytes') && !fm_validate_magic_bytes($tempFile, $validatedExt)) {
            @unlink($tempFile);
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'File signature does not match extension.')));
            exit();
        }

        $targetPath = $this->buildUniqueTargetPath($targetBase, $sanitizedName);
        if (!@rename($tempFile, $targetPath)) {
            @unlink($tempFile);
            $this->emitUrlUploadEvent(array('fail' => array('message' => 'Failed to persist downloaded file to destination.')));
            exit();
        }

        if (function_exists('fm_owner_meta_touch')) {
            fm_owner_meta_touch($targetPath, 'upload_url');
        }

        $result = new stdClass();
        $result->name = basename($targetPath);
        $result->size = (int) filesize($targetPath);
        $result->type = (string) $downloadResult['contentType'];
        $this->emitUrlUploadEvent(array('done' => $result));
        exit();
    }

    private function emitUrlUploadEvent($message) {
        echo json_encode($message);
    }

    private function sanitizeUploadFileName($name) {
        $name = str_replace('\\', '/', (string) $name);
        $name = basename($name);
        $name = preg_replace('/[\x00-\x1F\x7F]+/', '', $name);
        $name = trim((string) $name, " .\t\n\r\0\x0B");

        if ($name === '' || $name === '.' || $name === '..') {
            return '';
        }

        return $name;
    }

    private function sanitizeUploadRelativePath($path) {
        $path = str_replace('\\', '/', trim((string) $path));
        if ($path === '') {
            return '';
        }

        if (strpos($path, "\0") !== false) {
            return '';
        }

        if (preg_match('/^[a-zA-Z]:\//', $path) || strpos($path, '/') === 0 || strpos($path, '//') === 0) {
            return '';
        }

        if (strpos($path, '../') !== false || strpos($path, '/..') !== false || strpos($path, '..\\') !== false) {
            return '';
        }

        $parts = explode('/', $path);
        $safeParts = array();
        foreach ($parts as $part) {
            $part = preg_replace('/[\x00-\x1F\x7F]+/', '', (string) $part);
            $part = trim((string) $part, " .\t\n\r\0\x0B");
            if ($part === '' || $part === '.' || $part === '..') {
                continue;
            }
            if (!fm_isvalid_filename($part)) {
                return '';
            }
            $safeParts[] = $part;
        }

        if (empty($safeParts)) {
            return '';
        }

        return implode('/', $safeParts);
    }

    private function isAllowedRemoteUrl($url) {
        $parts = parse_url((string) $url);
        if (!is_array($parts)) {
            return false;
        }

        $scheme = isset($parts['scheme']) ? strtolower((string) $parts['scheme']) : '';
        if ($scheme !== 'http' && $scheme !== 'https') {
            return false;
        }

        if (isset($parts['user']) || isset($parts['pass'])) {
            return false;
        }

        $host = isset($parts['host']) ? strtolower((string) $parts['host']) : '';
        if ($host === '' || $host === 'localhost') {
            return false;
        }

        $port = isset($parts['port']) ? (int) $parts['port'] : 0;
        if (in_array($port, array(22, 23, 25, 3306), true)) {
            return false;
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if (!$this->isPublicIpAddress($host)) {
                return false;
            }
        } else {
            $resolvedIps = $this->resolveHostIps($host);
            if (empty($resolvedIps)) {
                return false;
            }
            foreach ($resolvedIps as $ip) {
                if (!$this->isPublicIpAddress($ip)) {
                    return false;
                }
            }
        }

        return true;
    }

    private function downloadRemoteFile($url, $tempFile, $maxBytes) {
        if (function_exists('curl_init')) {
            return $this->downloadRemoteFileWithCurl($url, $tempFile, $maxBytes);
        }

        $result = array(
            'success' => false,
            'message' => 'Failed to download file from URL.',
            'status' => 0,
            'headers' => array(),
            'contentType' => '',
        );

        $httpHeaders = array();
        $context = stream_context_create(array(
            'http' => array(
                'method' => 'GET',
                'timeout' => 25,
                'ignore_errors' => true,
                'follow_location' => 0,
                'max_redirects' => 0,
                'header' => "User-Agent: tinyfilemanager-url-upload/1.0\r\n",
            ),
        ));

        $in = @fopen($url, 'rb', false, $context);
        if ($in === false) {
            $result['message'] = 'Remote download failed.';
            return $result;
        }

        $meta = stream_get_meta_data($in);
        if (!empty($meta['wrapper_data']) && is_array($meta['wrapper_data'])) {
            $httpHeaders = $meta['wrapper_data'];
        }

        $result['headers'] = $httpHeaders;
        $status = $this->extractHttpStatus($httpHeaders);
        $result['status'] = $status;
        $result['contentType'] = $this->extractContentType($httpHeaders);

        if ($status >= 300 && $status < 400) {
            fclose($in);
            $result['message'] = 'Remote URL redirects are not allowed for security reasons.';
            return $result;
        }

        if ($status < 200 || $status >= 300) {
            fclose($in);
            $result['message'] = 'Remote server returned HTTP ' . $status . '.';
            return $result;
        }

        $out = @fopen($tempFile, 'wb');
        if ($out === false) {
            fclose($in);
            $result['message'] = 'Cannot open temporary file for writing.';
            return $result;
        }

        $bytesWritten = 0;
        while (!feof($in)) {
            $chunk = fread($in, 8192);
            if ($chunk === false) {
                fclose($in);
                fclose($out);
                $result['message'] = 'Remote download stream failed.';
                return $result;
            }

            $chunkLen = strlen($chunk);
            if ($chunkLen === 0) {
                continue;
            }

            $bytesWritten += $chunkLen;
            if ($maxBytes > 0 && $bytesWritten > $maxBytes) {
                fclose($in);
                fclose($out);
                $result['message'] = 'Downloaded file exceeds maximum allowed size.';
                return $result;
            }

            if (fwrite($out, $chunk) === false) {
                fclose($in);
                fclose($out);
                $result['message'] = 'Failed to persist downloaded content.';
                return $result;
            }
        }

        fclose($in);
        fclose($out);

        if (!is_file($tempFile) || filesize($tempFile) === 0) {
            $result['message'] = 'Failed to persist downloaded content.';
            return $result;
        }

        $result['success'] = true;
        return $result;
    }

    private function downloadRemoteFileWithCurl($url, $tempFile, $maxBytes) {
        $result = array(
            'success' => false,
            'message' => 'Failed to download file from URL.',
            'status' => 0,
            'headers' => array(),
            'contentType' => '',
        );

        $fp = @fopen($tempFile, 'wb');
        if ($fp === false) {
            $result['message'] = 'Cannot open temporary file for writing.';
            return $result;
        }

        $maxExceeded = false;
        $result['headers'] = array();
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_USERAGENT, 'tinyfilemanager-url-upload/1.0');
        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
        }
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
        }
        if (defined('CURLOPT_NOPROGRESS')) {
            curl_setopt($ch, CURLOPT_NOPROGRESS, false);
        }
        if (defined('CURLOPT_XFERINFOFUNCTION')) {
            curl_setopt($ch, CURLOPT_XFERINFOFUNCTION, function ($resource, $downloadSize, $downloaded, $uploadSize, $uploaded) use ($maxBytes, &$maxExceeded) {
                if ($maxBytes > 0 && $downloaded > $maxBytes) {
                    $maxExceeded = true;
                    return 1;
                }
                return 0;
            });
        }
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($ch, $headerLine) use (&$result) {
            $trimmed = trim((string) $headerLine);
            if ($trimmed !== '') {
                $result['headers'][] = $trimmed;
            }
            return strlen($headerLine);
        });
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $data) use ($fp, $maxBytes, &$maxExceeded) {
            if ($maxExceeded) {
                return 0;
            }
            if ($maxBytes > 0 && (ftell($fp) + strlen($data)) > $maxBytes) {
                $maxExceeded = true;
                return 0;
            }
            return fwrite($fp, $data);
        });

        $ok = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $curlError = curl_error($ch);
        curl_close($ch);
        fclose($fp);

        $result['status'] = $httpCode;
        $result['contentType'] = $contentType;

        if ($maxExceeded) {
            $result['message'] = 'Downloaded file exceeds maximum allowed size.';
            return $result;
        }

        if ($ok !== true) {
            $result['message'] = $curlError !== '' ? $curlError : 'Remote download failed.';
            return $result;
        }

        if ($httpCode >= 300 && $httpCode < 400) {
            $result['message'] = 'Remote URL redirects are not allowed for security reasons.';
            return $result;
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            $result['message'] = 'Remote server returned HTTP ' . $httpCode . '.';
            return $result;
        }

        if (!is_file($tempFile) || filesize($tempFile) === 0) {
            $result['message'] = 'Remote download returned an empty file.';
            return $result;
        }

        $result['success'] = true;
        return $result;
    }

    private function extractHttpStatus($headers) {
        if (!is_array($headers)) {
            return 0;
        }
        for ($i = count($headers) - 1; $i >= 0; $i--) {
            if (preg_match('/^HTTP\/\d(?:\.\d)?\s+(\d{3})/i', (string) $headers[$i], $m)) {
                return (int) $m[1];
            }
        }
        return 0;
    }

    private function extractContentType($headers) {
        if (!is_array($headers)) {
            return '';
        }
        for ($i = count($headers) - 1; $i >= 0; $i--) {
            if (stripos((string) $headers[$i], 'content-type:') === 0) {
                return trim((string) substr((string) $headers[$i], strlen('content-type:')));
            }
        }
        return '';
    }

    private function resolveUploadUrlFileName($url, $headers) {
        $dispositionName = $this->extractFilenameFromHeaders($headers);
        if ($dispositionName !== '') {
            return $dispositionName;
        }

        $pathName = rawurldecode((string) basename((string) parse_url((string) $url, PHP_URL_PATH)));
        if ($pathName !== '' && $pathName !== '/' && $pathName !== '.') {
            return $pathName;
        }

        $query = (string) parse_url((string) $url, PHP_URL_QUERY);
        if ($query !== '') {
            parse_str($query, $params);
            foreach (array('filename', 'file', 'name', 'download') as $key) {
                if (!empty($params[$key]) && is_string($params[$key])) {
                    return (string) $params[$key];
                }
            }
        }

        return 'downloaded-file';
    }

    private function extractFilenameFromHeaders($headers) {
        if (!is_array($headers)) {
            return '';
        }

        for ($i = count($headers) - 1; $i >= 0; $i--) {
            $line = (string) $headers[$i];
            if (stripos($line, 'content-disposition:') !== 0) {
                continue;
            }

            if (preg_match('/filename\*=(?:UTF-8\'\')?([^;]+)/i', $line, $m)) {
                return rawurldecode(trim($m[1], " \t\"'"));
            }
            if (preg_match('/filename=([^;]+)/i', $line, $m)) {
                return trim($m[1], " \t\"'");
            }
        }

        return '';
    }

    private function guessExtensionFromContentType($contentType) {
        $contentType = strtolower(trim((string) $contentType));
        if ($contentType === '') {
            return '';
        }
        $contentType = trim((string) strtok($contentType, ';'));

        $map = array(
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
            'text/plain' => 'txt',
            'text/csv' => 'csv',
            'application/zip' => 'zip',
            'application/json' => 'json',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'application/vnd.ms-powerpoint' => 'ppt',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
        );

        return isset($map[$contentType]) ? $map[$contentType] : '';
    }

    private function buildUniqueTargetPath($targetBase, $fileName) {
        $targetBase = rtrim(str_replace('\\', '/', (string) $targetBase), '/');
        $fileName = (string) $fileName;
        $candidate = $targetBase . '/' . $fileName;

        if (!file_exists($candidate)) {
            return $candidate;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $nameOnly = pathinfo($fileName, PATHINFO_FILENAME);
        $suffix = '_' . date('ymdHis');
        return $targetBase . '/' . $nameOnly . $suffix . ($ext !== '' ? '.' . $ext : '');
    }

    private function resolveUploadBasePath($requestedUploadDir) {
        $requestedUploadDir = fm_clean_path((string) $requestedUploadDir);
        $candidateBase = rtrim($this->root_path, '/\\');
        if ($requestedUploadDir !== '') {
            $candidateBase .= '/' . $requestedUploadDir;
        }

        $candidateBase = str_replace('\\', '/', $candidateBase);
        $normalizedRoot = rtrim(str_replace('\\', '/', (string) $this->root_path), '/');
        if (!fm_is_path_inside($candidateBase, $normalizedRoot)) {
            return null;
        }

        if (function_exists('fm_user_can_access_path') && !fm_user_can_access_path($candidateBase, false)) {
            return null;
        }

        return $candidateBase;
    }

    private function isPublicIpAddress($ip) {
        return (bool) filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    private function resolveHostIps($host) {
        $ips = array();

        if (function_exists('dns_get_record')) {
            $aRecords = @dns_get_record($host, DNS_A);
            if (is_array($aRecords)) {
                foreach ($aRecords as $record) {
                    if (!empty($record['ip'])) {
                        $ips[] = (string) $record['ip'];
                    }
                }
            }

            $aaaaRecords = @dns_get_record($host, DNS_AAAA);
            if (is_array($aaaaRecords)) {
                foreach ($aaaaRecords as $record) {
                    if (!empty($record['ipv6'])) {
                        $ips[] = (string) $record['ipv6'];
                    }
                }
            }
        }

        if (empty($ips)) {
            $legacy = @gethostbynamel($host);
            if (is_array($legacy)) {
                $ips = array_merge($ips, $legacy);
            }
        }

        $ips = array_values(array_unique(array_filter(array_map('trim', $ips), function ($value) {
            return $value !== '';
        })));

        return $ips;
    }
}
