<?php $all_files_size = 0; ?>
<script src="src/assets/js/navbar-padding-fix.js?v=<?php echo rawurlencode((string) VERSION); ?>"></script>
<form action="" method="post" class="pt-3 fm-shell">
    <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
    <input type="hidden" name="group" value="1">
    <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
    <div class="fm-listing-toolbar mb-3">
        <div class="fm-listing-toolbar__meta">
            <span class="badge text-bg-light fm-toolbar-badge"><?php echo lng('File') ?>: <?php echo (int) $num_files; ?></span>
            <span class="badge text-bg-light fm-toolbar-badge"><?php echo lng('Folder') ?>: <?php echo (int) $num_folders; ?></span>
            <span class="badge text-bg-light fm-toolbar-badge"><?php echo lng('FullSize') ?>: <?php echo fm_get_filesize($all_files_size); ?></span>
        </div>
        <div class="btn-group btn-group-sm fm-view-switch" role="group" aria-label="View mode">
            <button type="button" class="btn btn-outline-primary js-view-mode active" data-view-mode="list">
                <i class="fa fa-list" aria-hidden="true"></i> Zoznam
            </button>
            <button type="button" class="btn btn-outline-primary js-view-mode" data-view-mode="grid">
                <i class="fa fa-th-large" aria-hidden="true"></i> Mriežka
            </button>
        </div>
        <?php if (!FM_IS_WIN && !$hide_Cols): ?>
            <div class="fm-owner-filter-wrap">
                <label for="fm-owner-source-filter" class="fm-owner-filter-label">Vlastnik:</label>
                <select id="fm-owner-source-filter" class="form-select form-select-sm fm-owner-filter" aria-label="Filter owner source">
                    <option value="all">Vsetko</option>
                    <option value="app">App</option>
                    <option value="system">System</option>
                </select>
                <span class="badge text-bg-light fm-owner-source-count" id="fm-owner-count-app" data-owner-filter-target="app" tabindex="0" role="button" title="Pocet App owner poloziek (klik pre filter)">App: 0</span>
                <span class="badge text-bg-light fm-owner-source-count" id="fm-owner-count-system" data-owner-filter-target="system" tabindex="0" role="button" title="Pocet System owner poloziek (klik pre filter)">System: 0</span>
            </div>
        <?php endif; ?>
    </div>
    <div class="table-responsive fm-table-wrap fm-list-clean-wrap">
        <table class="table table-hover table-sm align-middle fm-modern-table fm-list-clean" id="main-table" data-bs-theme="<?php echo FM_THEME; ?>">
            <thead class="thead-white">
                <tr>
                    <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                        <th style="width:3%" class="custom-checkbox-header">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="js-select-all-items" onclick="checkbox_toggle()">
                                <label class="custom-control-label" for="js-select-all-items"></label>
                            </div>
                        </th><?php endif; ?>
                    <th class="fm-col-name"><?php echo lng('Name') ?></th>
                    <th class="fm-col-size"><?php echo lng('Size') ?></th>
                    <th class="fm-col-modified"><?php echo lng('Modified') ?></th>
                    <?php if (!FM_IS_WIN && !$hide_Cols): ?>
                        <th class="fm-col-perms"><?php echo lng('Perms') ?></th>
                        <th class="fm-col-owner"><?php echo lng('Owner') ?></th><?php endif; ?>
                    <th class="fm-col-actions"><?php echo lng('Actions') ?></th>
                </tr>
            </thead>
            <?php
            if ($parent !== false) {
            ?>
                <tr class="fm-parent-row"><?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                        <td class="nosort"></td><?php endif; ?>
                    <td class="border-0 fm-col-name" data-sort>
                        <a href="?p=<?php echo urlencode($parent) ?>" class="fm-parent-nav-link" title="Prejst o uroven vyssie">
                            <span class="fm-parent-nav-icon" aria-hidden="true"><i class="fa fa-arrow-left"></i></span>
                            <span class="fm-parent-nav-text">Spat o uroven vyssie</span>
                        </a>
                    </td>
                    <td class="border-0 fm-col-size" data-order></td>
                    <td class="border-0 fm-col-modified" data-order></td>
                    <td class="border-0 fm-col-actions"></td>
                    <?php if (!FM_IS_WIN && !$hide_Cols) { ?>
                        <td class="border-0 fm-col-perms"></td>
                        <td class="border-0 fm-col-owner"></td>
                    <?php } ?>
                </tr>
            <?php
            }

            $fmBuildActionNote = static function ($meta, $fallbackModified, $isDirectory = false) {
                $label = 'Bez app zaznamu';
                $title = 'Bez zaznamu o poslednom app ukone';

                if (is_array($meta)) {
                    $lastActionRaw = isset($meta['last_action']) ? strtolower(trim((string) $meta['last_action'])) : '';

                    if ($lastActionRaw !== '') {
                        if (function_exists('fm_owner_meta_action_label')) {
                            $label = fm_owner_meta_action_label($lastActionRaw, $isDirectory);
                        } else {
                            $label = ucfirst(str_replace('_', ' ', $lastActionRaw));
                        }
                    } else {
                        $label = 'Uprava';
                    }

                    $updatedBy = isset($meta['updated_by']) ? trim((string) $meta['updated_by']) : '';
                    $updatedAt = isset($meta['updated_at']) && is_numeric($meta['updated_at']) ? (int) $meta['updated_at'] : 0;

                    if ($updatedBy !== '' && strtolower($updatedBy) !== 'system') {
                        $label .= ' · ' . $updatedBy;
                    }

                    if ($updatedAt > 0) {
                        $label .= ' · ' . date('d.m.Y H:i', $updatedAt);
                    }

                    $title = $label;
                    if ($updatedAt > 0) {
                        $title .= ' @ ' . date(FM_DATETIME_FORMAT, $updatedAt);
                    }
                } elseif ($fallbackModified !== '') {
                    $label = 'System · ' . (string) $fallbackModified;
                    $title = 'Posledna systemova zmena podla mtime: ' . (string) $fallbackModified;
                }

                return array('label' => $label, 'title' => $title);
            };

            $ii = 3399;
            foreach ($folders as $f) {
                $is_link = is_link($path . '/' . $f);
                $img = $is_link ? 'icon-link_folder' : 'fa fa-folder-o';
                $modif_raw = filemtime($path . '/' . $f);
                $modif = date(FM_DATETIME_FORMAT, $modif_raw);
                $date_sorting = strtotime(date("F d Y H:i:s.", $modif_raw));
                $filesize_raw = "";
                $filesize = lng('Folder');
                $perms = substr(decoct(fileperms($path . '/' . $f)), -4);
                $owner = array('name' => '?');
                $group = array('name' => '?');
                if (function_exists('posix_getpwuid') && function_exists('posix_getgrgid')) {
                    try {
                        $owner_id = fileowner($path . '/' . $f);
                        if ($owner_id != 0) {
                            $owner_info = posix_getpwuid($owner_id);
                            if ($owner_info) {
                                $owner =  $owner_info;
                            }
                        }
                        $group_id = filegroup($path . '/' . $f);
                        $group_info = posix_getgrgid($group_id);
                        if ($group_info) {
                            $group =  $group_info;
                        }
                    } catch (Exception $e) {
                        error_log("exception:" . $e->getMessage());
                    }
                }
            ?>
                <tr>
                    <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                        <td class="custom-checkbox-td">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="<?php echo $ii ?>" name="file[]" value="<?php echo fm_enc($f) ?>">
                                <label class="custom-control-label" for="<?php echo $ii ?>"></label>
                            </div>
                        </td>
                    <?php endif; ?>
                    <td class="fm-col-name" data-sort=<?php echo fm_convert_win(fm_enc($f)) ?>>
                        <div class="filename">
                            <a href="?p=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')) ?>"><i class="<?php echo $img ?>"></i> <?php echo fm_convert_win(fm_enc($f)) ?></a>
                            <?php echo ($is_link ? ' &rarr; <i>' . readlink($path . '/' . $f) . '</i>' : '') ?>
                        </div>
                    </td>
                    <td class="fm-col-size" data-order="a-<?php echo str_pad($filesize_raw, 18, "0", STR_PAD_LEFT); ?>">
                        <?php echo $filesize; ?>
                    </td>
                    <td class="fm-col-modified" data-order="a-<?php echo $date_sorting; ?>"><?php echo $modif ?></td>
                    <?php if (!FM_IS_WIN && !$hide_Cols) { ?>
                        <?php
                        $ownerName = isset($owner['name']) ? (string) $owner['name'] : '?';
                        $groupName = isset($group['name']) ? (string) $group['name'] : '?';
                        $ownerTitle = $ownerName . ':' . $groupName;
                        $hasAppOwner = false;
                        $ownerSource = 'system';
                        $lastEditorName = '';
                        $lastEditorTitle = '';
                        $appOwnerMeta = function_exists('fm_owner_meta_get') ? fm_owner_meta_get($path . '/' . $f) : null;
                        if (is_array($appOwnerMeta)) {
                            $appCreatedBy = isset($appOwnerMeta['created_by']) ? trim((string) $appOwnerMeta['created_by']) : '';
                            $appUpdatedBy = isset($appOwnerMeta['updated_by']) ? trim((string) $appOwnerMeta['updated_by']) : '';
                            $ownerSource = isset($appOwnerMeta['owner_source']) ? strtolower(trim((string) $appOwnerMeta['owner_source'])) : '';
                            if ($ownerSource !== 'app' && $ownerSource !== 'system') {
                                $ownerSource = ($appCreatedBy !== '' && strtolower($appCreatedBy) !== 'system') ? 'app' : 'system';
                            }
                            if ($ownerSource === 'app' && $appCreatedBy !== '') {
                                $hasAppOwner = true;
                                $ownerName = $appCreatedBy;
                                $ownerLabel = $appCreatedBy;
                                $ownerTitle = 'App owner: ' . $appCreatedBy;
                                if ($appUpdatedBy !== '' && $appUpdatedBy !== $appCreatedBy) {
                                    $ownerTitle .= ' | Last update: ' . $appUpdatedBy;
                                }
                            } elseif ($ownerSource === 'system' && $appUpdatedBy !== '' && strtolower($appUpdatedBy) !== 'system') {
                                $lastEditorName = $appUpdatedBy;
                                $lastEditorTitle = 'Last update: ' . $appUpdatedBy;
                            }
                        }
                        $ownerLabel = $ownerName;
                        if (!$hasAppOwner) {
                            if (!empty($owner['gecos'])) {
                                $ownerGecos = trim((string) $owner['gecos']);
                                if ($ownerGecos !== '') {
                                    $ownerLabel = $ownerGecos;
                                }
                            }
                            if (preg_match('/^u[0-9]{5,}$/', $ownerLabel)) {
                                $ownerLabel = 'System';
                            }
                        }
                        $canChatWithOwner = FM_USE_AUTH
                            && !empty($_SESSION[FM_SESSION_ID]['logged'])
                            && isset($auth_users)
                            && is_array($auth_users)
                            && isset($auth_users[$ownerName]);
                        $isSelfOwnerBadge = !empty($_SESSION[FM_SESSION_ID]['logged']) && $_SESSION[FM_SESSION_ID]['logged'] === $ownerName;
                        $canChatWithLastEditor = FM_USE_AUTH
                            && !empty($_SESSION[FM_SESSION_ID]['logged'])
                            && $lastEditorName !== ''
                            && isset($auth_users)
                            && is_array($auth_users)
                            && isset($auth_users[$lastEditorName]);
                        $isSelfLastEditorBadge = !empty($_SESSION[FM_SESSION_ID]['logged']) && $_SESSION[FM_SESSION_ID]['logged'] === $lastEditorName;
                        $actionNote = $fmBuildActionNote($appOwnerMeta, $modif, true);
                        ?>
                        <td class="fm-col-perms"><?php echo $perms ?></td>
                        <td class="fm-col-owner" data-owner-source="<?php echo $ownerSource === 'app' ? 'app' : 'system'; ?>">
                            <div class="fm-owner-stack">
                                <button
                                    type="button"
                                    class="badge border-0 fm-user-chat-badge fm-owner-badge <?php echo ($canChatWithOwner && !$isSelfOwnerBadge) ? 'text-bg-secondary' : 'text-bg-light'; ?>"
                                    data-chat-user="<?php echo ($canChatWithOwner && !$isSelfOwnerBadge) ? fm_enc($ownerName) : ''; ?>"
                                    title="<?php echo fm_enc($ownerTitle); ?>"
                                    <?php echo (!$canChatWithOwner || $isSelfOwnerBadge) ? 'disabled' : ''; ?>
                                >
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                    <span><?php echo fm_enc($ownerLabel); ?></span>
                                </button>
                                <?php if ($lastEditorName !== ''): ?>
                                    <button
                                        type="button"
                                        class="badge border-0 fm-user-chat-badge fm-owner-badge fm-owner-last-editor-badge <?php echo ($canChatWithLastEditor && !$isSelfLastEditorBadge) ? 'text-bg-secondary' : 'text-bg-light'; ?>"
                                        data-chat-user="<?php echo ($canChatWithLastEditor && !$isSelfLastEditorBadge) ? fm_enc($lastEditorName) : ''; ?>"
                                        title="<?php echo fm_enc($lastEditorTitle); ?>"
                                        <?php echo (!$canChatWithLastEditor || $isSelfLastEditorBadge) ? 'disabled' : ''; ?>
                                    >
                                        <i class="fa fa-pencil" aria-hidden="true"></i>
                                        <span><?php echo fm_enc($lastEditorName); ?></span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    <?php } ?>
                    <td class="fm-col-actions">
                        <div class="fm-action-note" title="<?php echo fm_enc($actionNote['title']); ?>">
                            <i class="fa fa-history" aria-hidden="true"></i>
                            <span><?php echo fm_enc($actionNote['label']); ?></span>
                        </div>
                        <div class="inline-actions">
                            <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                                <?php if (!FM_MANAGER): ?>
                                <a title="<?php echo lng('Delete') ?>" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;del=<?php echo urlencode($f) ?>" onclick="confirmDailog(event, '1028','<?php echo lng('Delete') . ' ' . lng('Folder'); ?>','<?php echo urlencode($f) ?>', this.href);"> <i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                <?php endif; ?>
                                <a title="<?php echo lng('Rename') ?>" href="#" onclick="rename('<?php echo fm_enc(addslashes(FM_PATH)) ?>', '<?php echo fm_enc(addslashes($f)) ?>');return false;"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                <a title="<?php echo lng('CopyTo') ?>..." href="?p=&amp;copy=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')) ?>"><i class="fa fa-files-o" aria-hidden="true"></i></a>
                            <?php endif; ?>
                            <a title="<?php echo lng('DirectLink') ?>" href="<?php echo fm_enc(FM_ROOT_URL . (FM_PATH != '' ? '/' . FM_PATH : '') . '/' . $f . '/') ?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                        </div>
                    </td>
                </tr>
            <?php
                flush();
                $ii++;
            }
            // End foreach folders
            $ik = 8002;
            foreach ($files as $f) {
                $is_link = is_link($path . '/' . $f);
                $img = $is_link ? 'fa fa-file-text-o' : fm_get_file_icon_class($path . '/' . $f);
                $modif_raw = filemtime($path . '/' . $f);
                $modif = date(FM_DATETIME_FORMAT, $modif_raw);
                $date_sorting = strtotime(date("F d Y H:i:s.", $modif_raw));
                $filesize_raw = fm_get_size($path . '/' . $f);
                $filesize = fm_get_filesize($filesize_raw);
                $filelink = '?p=' . urlencode(FM_PATH) . '&amp;view=' . urlencode($f);
                $all_files_size += $filesize_raw;
                $perms = substr(decoct(fileperms($path . '/' . $f)), -4);
                $owner = array('name' => '?');
                $group = array('name' => '?');
                if (function_exists('posix_getpwuid') && function_exists('posix_getgrgid')) {
                    try {
                        $owner_id = fileowner($path . '/' . $f);
                        if ($owner_id != 0) {
                            $owner_info = posix_getpwuid($owner_id);
                            if ($owner_info) {
                                $owner =  $owner_info;
                            }
                        }
                        $group_id = filegroup($path . '/' . $f);
                        $group_info = posix_getgrgid($group_id);
                        if ($group_info) {
                            $group =  $group_info;
                        }
                    } catch (Exception $e) {
                        error_log("exception:" . $e->getMessage());
                    }
                }
            ?>
                <tr>
                    <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                        <td class="custom-checkbox-td">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="<?php echo $ik ?>" name="file[]" value="<?php echo fm_enc($f) ?>">
                                <label class="custom-control-label" for="<?php echo $ik ?>"></label>
                            </div>
                        </td><?php endif; ?>
                    <td class="fm-col-name" data-sort=<?php echo fm_enc($f) ?>>
                        <div class="filename">
                            <?php
                            $ext_lower = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                            $previewUrl = fm_enc(FM_SELF_PATH . '?' . fm_build_preview_query(FM_PATH, $f));
                            $item_mime = fm_get_mime_type($path . '/' . $f);
                            $previewType = '';
                            $isPdf = false;
                            if (in_array($ext_lower, array('gif', 'jpg', 'jpeg', 'png', 'bmp', 'ico', 'svg', 'webp', 'avif')) || fm_is_image_mime_type($item_mime)) {
                                $previewType = 'image';
                            } elseif (in_array($ext_lower, array('mp4', 'webm', 'ogg', 'mov', 'm4v'))) {
                                $previewType = 'video';
                            } elseif ($ext_lower === 'pdf') {
                                $isPdf = true;
                            }
                            ?>
                            <a href="<?php echo $filelink ?>" data-full-path="<?php echo fm_enc(trim(FM_PATH . '/' . $f, '/')); ?>" <?php echo $previewType ? 'data-preview-type="' . $previewType . '" data-preview-src="' . $previewUrl . '"' : ''; ?> <?php echo $isPdf ? 'data-preview-type="pdf"' : ''; ?> <?php echo $previewType === 'image' ? 'data-preview-image="' . $previewUrl . '"' : ''; ?> title="<?php echo fm_enc($f) ?>">
                                <i class="<?php echo $img ?>"></i> <?php echo fm_convert_win(fm_enc($f)) ?>
                            </a>
                            <?php echo ($is_link ? ' &rarr; <i>' . readlink($path . '/' . $f) . '</i>' : '') ?>
                        </div>
                    </td>
                    <td class="fm-col-size" data-order="b-<?php echo str_pad($filesize_raw, 18, "0", STR_PAD_LEFT); ?>"><span title="<?php printf('%s bytes', $filesize_raw) ?>">
                            <?php echo $filesize; ?>
                        </span></td>
                    <td class="fm-col-modified" data-order="b-<?php echo $date_sorting; ?>"><?php echo $modif ?></td>
                    <?php if (!FM_IS_WIN && !$hide_Cols): ?>
                        <?php
                        $ownerName = isset($owner['name']) ? (string) $owner['name'] : '?';
                        $groupName = isset($group['name']) ? (string) $group['name'] : '?';
                        $ownerTitle = $ownerName . ':' . $groupName;
                        $hasAppOwner = false;
                        $ownerSource = 'system';
                        $lastEditorName = '';
                        $lastEditorTitle = '';
                        $appOwnerMeta = function_exists('fm_owner_meta_get') ? fm_owner_meta_get($path . '/' . $f) : null;
                        if (is_array($appOwnerMeta)) {
                            $appCreatedBy = isset($appOwnerMeta['created_by']) ? trim((string) $appOwnerMeta['created_by']) : '';
                            $appUpdatedBy = isset($appOwnerMeta['updated_by']) ? trim((string) $appOwnerMeta['updated_by']) : '';
                            $ownerSource = isset($appOwnerMeta['owner_source']) ? strtolower(trim((string) $appOwnerMeta['owner_source'])) : '';
                            if ($ownerSource !== 'app' && $ownerSource !== 'system') {
                                $ownerSource = ($appCreatedBy !== '' && strtolower($appCreatedBy) !== 'system') ? 'app' : 'system';
                            }
                            if ($ownerSource === 'app' && $appCreatedBy !== '') {
                                $hasAppOwner = true;
                                $ownerName = $appCreatedBy;
                                $ownerLabel = $appCreatedBy;
                                $ownerTitle = 'App owner: ' . $appCreatedBy;
                                if ($appUpdatedBy !== '' && $appUpdatedBy !== $appCreatedBy) {
                                    $ownerTitle .= ' | Last update: ' . $appUpdatedBy;
                                }
                            } elseif ($ownerSource === 'system' && $appUpdatedBy !== '' && strtolower($appUpdatedBy) !== 'system') {
                                $lastEditorName = $appUpdatedBy;
                                $lastEditorTitle = 'Last update: ' . $appUpdatedBy;
                            }
                        }
                        $ownerLabel = $ownerName;
                        if (!$hasAppOwner) {
                            if (!empty($owner['gecos'])) {
                                $ownerGecos = trim((string) $owner['gecos']);
                                if ($ownerGecos !== '') {
                                    $ownerLabel = $ownerGecos;
                                }
                            }
                            if (preg_match('/^u[0-9]{5,}$/', $ownerLabel)) {
                                $ownerLabel = 'System';
                            }
                        }
                        $canChatWithOwner = FM_USE_AUTH
                            && !empty($_SESSION[FM_SESSION_ID]['logged'])
                            && isset($auth_users)
                            && is_array($auth_users)
                            && isset($auth_users[$ownerName]);
                        $isSelfOwnerBadge = !empty($_SESSION[FM_SESSION_ID]['logged']) && $_SESSION[FM_SESSION_ID]['logged'] === $ownerName;
                        $canChatWithLastEditor = FM_USE_AUTH
                            && !empty($_SESSION[FM_SESSION_ID]['logged'])
                            && $lastEditorName !== ''
                            && isset($auth_users)
                            && is_array($auth_users)
                            && isset($auth_users[$lastEditorName]);
                        $isSelfLastEditorBadge = !empty($_SESSION[FM_SESSION_ID]['logged']) && $_SESSION[FM_SESSION_ID]['logged'] === $lastEditorName;
                        $actionNote = $fmBuildActionNote($appOwnerMeta, $modif, false);
                        ?>
                        <td class="fm-col-perms"><?php if (!FM_READONLY): ?><a title="<?php echo 'Change Permissions' ?>" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;chmod=<?php echo urlencode($f) ?>"><?php echo $perms ?></a><?php else: ?><?php echo $perms ?><?php endif; ?>
                        </td>
                        <td class="fm-col-owner" data-owner-source="<?php echo $ownerSource === 'app' ? 'app' : 'system'; ?>">
                            <div class="fm-owner-stack">
                                <button
                                    type="button"
                                    class="badge border-0 fm-user-chat-badge fm-owner-badge <?php echo ($canChatWithOwner && !$isSelfOwnerBadge) ? 'text-bg-secondary' : 'text-bg-light'; ?>"
                                    data-chat-user="<?php echo ($canChatWithOwner && !$isSelfOwnerBadge) ? fm_enc($ownerName) : ''; ?>"
                                    title="<?php echo fm_enc($ownerTitle); ?>"
                                    <?php echo (!$canChatWithOwner || $isSelfOwnerBadge) ? 'disabled' : ''; ?>
                                >
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                    <span><?php echo fm_enc($ownerLabel); ?></span>
                                </button>
                                <?php if ($lastEditorName !== ''): ?>
                                    <button
                                        type="button"
                                        class="badge border-0 fm-user-chat-badge fm-owner-badge fm-owner-last-editor-badge <?php echo ($canChatWithLastEditor && !$isSelfLastEditorBadge) ? 'text-bg-secondary' : 'text-bg-light'; ?>"
                                        data-chat-user="<?php echo ($canChatWithLastEditor && !$isSelfLastEditorBadge) ? fm_enc($lastEditorName) : ''; ?>"
                                        title="<?php echo fm_enc($lastEditorTitle); ?>"
                                        <?php echo (!$canChatWithLastEditor || $isSelfLastEditorBadge) ? 'disabled' : ''; ?>
                                    >
                                        <i class="fa fa-pencil" aria-hidden="true"></i>
                                        <span><?php echo fm_enc($lastEditorName); ?></span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    <?php endif; ?>
                    <td class="fm-col-actions">
                        <div class="fm-action-note" title="<?php echo fm_enc($actionNote['title']); ?>">
                            <i class="fa fa-history" aria-hidden="true"></i>
                            <span><?php echo fm_enc($actionNote['label']); ?></span>
                        </div>
                        <div class="inline-actions">
                            <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
                                <?php if (!FM_MANAGER): ?>
                                <a title="<?php echo lng('Delete') ?>" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;del=<?php echo urlencode($f) ?>" onclick="confirmDailog(event, 1209, '<?php echo lng('Delete') . ' ' . lng('File'); ?>','<?php echo urlencode($f); ?>', this.href);"> <i class="fa fa-trash-o"></i></a>
                                <?php endif; ?>
                                <a title="<?php echo lng('Rename') ?>" href="#" onclick="rename('<?php echo fm_enc(addslashes(FM_PATH)) ?>', '<?php echo fm_enc(addslashes($f)) ?>');return false;"><i class="fa fa-pencil-square-o"></i></a>
                                <a title="<?php echo lng('CopyTo') ?>..."
                                    href="?p=<?php echo urlencode(FM_PATH) ?>&amp;copy=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')) ?>"><i class="fa fa-files-o"></i></a>
                            <?php endif; ?>
                            <a title="<?php echo lng('DirectLink') ?>" href="<?php echo fm_enc(FM_ROOT_URL . (FM_PATH != '' ? '/' . FM_PATH : '') . '/' . $f) ?>" target="_blank"><i class="fa fa-link"></i></a>
                            <a title="<?php echo lng('Download') ?>" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;dl=<?php echo urlencode($f) ?>" onclick="confirmDailog(event, 1211, '<?php echo lng('Download'); ?>','<?php echo urlencode($f); ?>', this.href);"><i class="fa fa-download"></i></a>
                        </div>
                    </td>
                </tr>
            <?php
                flush();
                $ik++;
            }
            // Close the foreach for $files

            if (empty($folders) && empty($files)) { ?>
                <tfoot>
                    <tr><?php if (!FM_READONLY): ?>
                            <td></td><?php endif; ?>
                        <td colspan="<?php echo (!FM_IS_WIN && !$hide_Cols) ? '6' : '4' ?>"><em><?php echo lng('Folder is empty') ?></em></td>
                    </tr>
                </tfoot>
            <?php
            } else { ?>
                <tfoot>
                    <tr>
                        <td class="gray fs-7" colspan="<?php echo (!FM_IS_WIN && !$hide_Cols) ? ((FM_READONLY || FM_UPLOAD_ONLY) ? '6' : '7') : ((FM_READONLY || FM_UPLOAD_ONLY) ? '4' : '5') ?>">
                            <?php echo lng('FullSize') . ': <span class="badge text-bg-light border-radius-0">' . fm_get_filesize($all_files_size) . '</span>' ?>
                            <?php echo lng('File') . ': <span class="badge text-bg-light border-radius-0">' . $num_files . '</span>' ?>
                            <?php echo lng('Folder') . ': <span class="badge text-bg-light border-radius-0">' . $num_folders . '</span>' ?>
                        </td>
                    </tr>
                </tfoot>
            <?php } ?>
        </table>
    </div>
    <div id="fm-grid-view" class="hidden"></div>

    <div class="row fm-footer-tools-row">
        <?php
        $footerLoggedUser = (FM_USE_AUTH && !empty($_SESSION[FM_SESSION_ID]['logged'])) ? $_SESSION[FM_SESSION_ID]['logged'] : '';
        $footerShowUserBadges = !empty($footerLoggedUser) && (FM_MANAGER || (!FM_READONLY && !FM_UPLOAD_ONLY));
        $footerOnlineUsers = $footerShowUserBadges ? fm_online_get_users() : array();
        if ($footerShowUserBadges && empty($footerOnlineUsers)) {
            $footerOnlineUsers = array($footerLoggedUser);
        }
        ?>
        <?php if (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH): ?>
            <div class="fm-footer-actions-col">
                <div id="fm-selection-bar" class="btn-group flex-wrap" data-toggle="buttons" role="toolbar">
                    <span id="fm-selection-count" class="btn btn-small btn-outline-secondary btn-2 pe-none" style="display:none;">0</span>
                    <a href="#/select-all" class="btn btn-small btn-outline-primary btn-2" onclick="select_all();return false;"><i class="fa fa-check-square"></i> <?php echo lng('SelectAll') ?> </a>
                    <a href="#/unselect-all" class="btn btn-small btn-outline-primary btn-2" onclick="unselect_all();return false;"><i class="fa fa-window-close"></i> <?php echo lng('UnSelectAll') ?> </a>
                    <a href="#/invert-all" class="btn btn-small btn-outline-primary btn-2" onclick="invert_all();return false;"><i class="fa fa-th-list"></i> <?php echo lng('InvertSelection') ?> </a>
                    <?php if (!FM_MANAGER): ?>
                    <input type="submit" class="hidden" name="delete" id="a-delete" value="Delete" onclick="return confirm('<?php echo lng('Delete selected files and folders?'); ?>')">
                    <a href="javascript:document.getElementById('a-delete').click();" class="btn btn-small btn-outline-primary btn-2"><i class="fa fa-trash"></i> <?php echo lng('Delete') ?> </a>
                    <?php endif; ?>
                    <input type="submit" class="hidden" name="zip" id="a-zip" value="zip" onclick="return confirm('<?php echo lng('Create archive?'); ?>')">
                    <a href="javascript:document.getElementById('a-zip').click();" class="btn btn-small btn-outline-primary btn-2"><i class="fa fa-file-archive-o"></i> <?php echo lng('Zip') ?> </a>
                    <input type="submit" class="hidden" name="tar" id="a-tar" value="tar" onclick="return confirm('<?php echo lng('Create archive?'); ?>')">
                    <a href="javascript:document.getElementById('a-tar').click();" class="btn btn-small btn-outline-primary btn-2"><i class="fa fa-file-archive-o"></i> <?php echo lng('Tar') ?> </a>
                    <input type="hidden" id="fm-bulk-move-flag" value="1">
                    <input type="submit" class="hidden" name="copy" id="a-copy" value="Copy">
                    <a href="javascript:(function(){var f=document.getElementById('fm-bulk-move-flag');if(f){f.removeAttribute('name');}document.getElementById('a-copy').click();})();" class="btn btn-small btn-outline-primary btn-2"><i class="fa fa-files-o"></i> <?php echo lng('Copy') ?> </a>
                    <a href="javascript:(function(){var f=document.getElementById('fm-bulk-move-flag');if(f){f.setAttribute('name','move');}document.getElementById('a-copy').click();})();" class="btn btn-small btn-outline-primary btn-2"><i class="fa fa-arrows"></i> <?php echo lng('Move') ?> </a>
                </div>
            </div>
            <div class="fm-footer-online-col">
                <?php if ($footerShowUserBadges): ?>
                    <div class="d-flex gap-2 align-items-center flex-wrap justify-content-sm-end justify-content-start fm-online-users-wrap">
                        <span class="badge text-bg-light border"><?php echo lng('Online users') ?>: <?php echo count($footerOnlineUsers); ?></span>
                        <?php if ($footerLoggedUser === 'admin'): ?>
                            <button
                                type="button"
                                class="badge border-0 text-bg-danger js-reset-runtime-state"
                            >
                                Reset cache + pripojenia
                            </button>
                        <?php endif; ?>
                        <span class="badge text-bg-warning border fm-chat-unread-badge" style="display:none;">
                            Neprecitane: <span class="fm-chat-unread-count">0</span>
                        </span>
                        <?php foreach ($footerOnlineUsers as $onlineUser): ?>
                            <button
                                type="button"
                                class="badge border-0 fm-user-chat-badge <?php echo ($onlineUser === $footerLoggedUser) ? 'text-bg-primary' : 'text-bg-secondary'; ?>"
                                data-chat-user="<?php echo fm_enc($onlineUser); ?>"
                                <?php echo ($onlineUser === $footerLoggedUser) ? 'disabled' : ''; ?>
                            >
                                <?php echo fm_enc($onlineUser); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <a href="https://tinyfilemanager.github.io" target="_blank" class="text-muted d-inline-block text-sm-end w-100">Tiny File Manager <?php echo VERSION; ?></a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="col-12">
                <?php if ($footerShowUserBadges): ?>
                    <div class="float-right d-flex gap-2 align-items-center flex-wrap">
                        <span class="badge text-bg-light border"><?php echo lng('Online users') ?>: <?php echo count($footerOnlineUsers); ?></span>
                        <?php if ($footerLoggedUser === 'admin'): ?>
                            <button
                                type="button"
                                class="badge border-0 text-bg-danger js-reset-runtime-state"
                            >
                                Reset cache + pripojenia
                            </button>
                        <?php endif; ?>
                        <span class="badge text-bg-warning border fm-chat-unread-badge" style="display:none;">
                            Neprecitane: <span class="fm-chat-unread-count">0</span>
                        </span>
                        <?php foreach ($footerOnlineUsers as $onlineUser): ?>
                            <button
                                type="button"
                                class="badge border-0 fm-user-chat-badge <?php echo ($onlineUser === $footerLoggedUser) ? 'text-bg-primary' : 'text-bg-secondary'; ?>"
                                data-chat-user="<?php echo fm_enc($onlineUser); ?>"
                                <?php echo ($onlineUser === $footerLoggedUser) ? 'disabled' : ''; ?>
                            >
                                <?php echo fm_enc($onlineUser); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <a href="https://tinyfilemanager.github.io" target="_blank" class="float-right text-muted">Tiny File Manager <?php echo VERSION; ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
    (function () {
        var resetButtons = document.querySelectorAll('.js-reset-runtime-state');
        if (!resetButtons.length) {
            return;
        }

        var token = <?php echo json_encode($_SESSION['token']); ?>;
        var requestInFlight = false;

        function setBusyState(isBusy) {
            for (var i = 0; i < resetButtons.length; i++) {
                resetButtons[i].disabled = isBusy;
                if (isBusy) {
                    resetButtons[i].setAttribute('aria-busy', 'true');
                } else {
                    resetButtons[i].removeAttribute('aria-busy');
                }
            }
        }

        function onResetClick(event) {
            event.preventDefault();
            if (requestInFlight) {
                return;
            }

            if (!window.confirm('Resetovat cache a vsetky pripojenia?')) {
                return;
            }

            requestInFlight = true;
            setBusyState(true);

            var body = new URLSearchParams();
            body.append('ajax', '1');
            body.append('type', 'reset_runtime_state');
            body.append('token', token);

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: body.toString(),
                credentials: 'same-origin'
            }).then(function (response) {
                return response.json();
            }).then(function (payload) {
                if (!payload || payload.success !== true) {
                    throw new Error((payload && payload.msg) ? payload.msg : 'Reset zlyhal.');
                }
                window.location.reload();
            }).catch(function (error) {
                window.alert(error && error.message ? error.message : 'Reset zlyhal.');
            }).finally(function () {
                requestInFlight = false;
                setBusyState(false);
            });
        }

        for (var i = 0; i < resetButtons.length; i++) {
            resetButtons[i].addEventListener('click', onResetClick);
        }
    })();
</script>

<style>
    .fm-footer-tools-row {
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;
        row-gap: .5rem;
    }

    .fm-footer-actions-col {
        flex: 1 1 58%;
        min-width: 320px;
    }

    .fm-footer-online-col {
        flex: 1 1 42%;
        min-width: 300px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
    }

    .fm-online-users-wrap {
        width: 100%;
    }

    @media (max-width: 991.98px) {
        .fm-footer-tools-row {
            flex-wrap: nowrap;
            align-items: center;
            column-gap: .5rem;
            overflow-x: auto;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
            padding-bottom: .2rem;
        }

        .fm-footer-actions-col {
            flex: 1 1 auto;
            min-width: 0;
        }

        .fm-footer-online-col {
            flex: 0 0 auto;
            min-width: 250px;
            max-width: 44vw;
            justify-content: flex-end;
        }

        .fm-footer-tools-row #fm-selection-bar {
            flex-wrap: nowrap;
            overflow-x: auto;
            overflow-y: hidden;
            white-space: nowrap;
            width: 100%;
            padding: 4px;
        }

        .fm-footer-tools-row #fm-selection-bar .btn.btn-2,
        .fm-footer-tools-row #fm-selection-bar #fm-selection-count {
            flex: 0 0 auto;
            min-height: 34px;
            padding-top: 0.2rem;
            padding-bottom: 0.2rem;
        }

        .fm-online-users-wrap {
            display: flex;
            flex-wrap: nowrap !important;
            overflow-x: auto;
            overflow-y: hidden;
            white-space: nowrap;
            justify-content: flex-end;
            width: 100%;
            gap: .35rem !important;
            padding-bottom: 2px;
        }

        .fm-online-users-wrap .badge,
        .fm-online-users-wrap .fm-user-chat-badge,
        .fm-online-users-wrap .js-reset-runtime-state {
            flex: 0 0 auto;
        }

        .fm-footer-tools-row #fm-selection-bar::-webkit-scrollbar,
        .fm-online-users-wrap::-webkit-scrollbar,
        .fm-footer-tools-row::-webkit-scrollbar {
            height: 5px;
        }

        .fm-footer-tools-row #fm-selection-bar::-webkit-scrollbar-thumb,
        .fm-online-users-wrap::-webkit-scrollbar-thumb,
        .fm-footer-tools-row::-webkit-scrollbar-thumb {
            background: rgba(120, 130, 150, 0.45);
            border-radius: 999px;
        }

        .fm-footer-tools-row #fm-selection-bar::-webkit-scrollbar-track,
        .fm-online-users-wrap::-webkit-scrollbar-track,
        .fm-footer-tools-row::-webkit-scrollbar-track {
            background: transparent;
        }
    }

    @media (max-width: 575.98px) {
        .fm-footer-online-col {
            min-width: 220px;
            max-width: 46vw;
        }

        .fm-footer-tools-row #fm-selection-bar .btn.btn-2,
        .fm-footer-tools-row #fm-selection-bar #fm-selection-count {
            min-height: 32px;
            font-size: .78rem;
        }

        .fm-online-users-wrap .badge,
        .fm-online-users-wrap .fm-user-chat-badge,
        .fm-online-users-wrap .js-reset-runtime-state {
            font-size: .72rem;
        }
    }
</style>

<script>
    (function () {
        var filterEl = document.getElementById('fm-owner-source-filter');
        var tableEl = document.getElementById('main-table');
        var tableWrapEl = document.querySelector('.fm-table-wrap');
        var gridViewEl = document.getElementById('fm-grid-view');
        var viewButtons = document.querySelectorAll('.js-view-mode');
        var countAppEl = document.getElementById('fm-owner-count-app');
        var countSystemEl = document.getElementById('fm-owner-count-system');
        var countBadgeEls = document.querySelectorAll('.fm-owner-source-count[data-owner-filter-target]');
        var canCreateNewItem = <?php echo (!FM_READONLY && !FM_UPLOAD_ONLY && FM_CAN_WRITE_IN_PATH) ? 'true' : 'false'; ?>;
        if (!tableEl) {
            return;
        }

        var currentViewMode = 'list';
        var floatingPanelEl = null;
        var floatingPanelTitleEl = null;
        var floatingPanelActionsEl = null;
        var activeFloatingRow = null;
        var hoverShowTimer = null;
        var hoverHideTimer = null;
        var HOVER_SHOW_DELAY_MS = 120;
        var HOVER_HIDE_DELAY_MS = 180;

        var dataTableFilterInstalled = false;

        function getSelectedSource() {
            return (filterEl.value || 'all').toLowerCase();
        }

        function rowMatchesFilter(row) {
            if (!filterEl) {
                return true;
            }
            var selected = getSelectedSource();
            if (selected === 'all') {
                return true;
            }

            var ownerCell = row.querySelector('td.fm-col-owner[data-owner-source]');
            if (!ownerCell) {
                return true;
            }

            return String(ownerCell.getAttribute('data-owner-source') || 'system').toLowerCase() === selected;
        }

        function applyPlainFilter() {
            var rows = tableEl.querySelectorAll('tbody tr');
            rows.forEach(function (row) {
                if (row.classList.contains('fm-parent-row')) {
                    row.style.display = '';
                    return;
                }
                row.style.display = rowMatchesFilter(row) ? '' : 'none';
            });
        }

        function refreshOwnerSourceCounts() {
            if (!countAppEl && !countSystemEl) {
                return;
            }
            var appCount = 0;
            var systemCount = 0;
            var ownerCells = tableEl.querySelectorAll('tbody td.fm-col-owner[data-owner-source]');

            ownerCells.forEach(function (cell) {
                var src = String(cell.getAttribute('data-owner-source') || 'system').toLowerCase();
                if (src === 'app') {
                    appCount++;
                } else {
                    systemCount++;
                }
            });

            if (countAppEl) {
                countAppEl.textContent = 'App: ' + appCount;
            }
            if (countSystemEl) {
                countSystemEl.textContent = 'System: ' + systemCount;
            }

            var selected = filterEl ? getSelectedSource() : 'all';
            countBadgeEls.forEach(function (el) {
                var target = String(el.getAttribute('data-owner-filter-target') || '').toLowerCase();
                if (target && target === selected) {
                    el.classList.add('is-active');
                } else {
                    el.classList.remove('is-active');
                }
            });
        }

        function ensureDataTableFilter() {
            if (!(window.jQuery && window.jQuery.fn && window.jQuery.fn.dataTable && window.jQuery.fn.dataTable.ext && window.jQuery.fn.dataTable.ext.search)) {
                return false;
            }

            if (!dataTableFilterInstalled) {
                window.jQuery.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
                    if (!settings || !settings.nTable || settings.nTable.id !== 'main-table') {
                        return true;
                    }

                    var api = new window.jQuery.fn.dataTable.Api(settings);
                    var rowNode = api.row(dataIndex).node();
                    if (!rowNode) {
                        return true;
                    }

                    if (rowNode.classList && rowNode.classList.contains('fm-parent-row')) {
                        return true;
                    }

                    return rowMatchesFilter(rowNode);
                });
                dataTableFilterInstalled = true;
            }

            if (window.mainTable && typeof window.mainTable.draw === 'function') {
                window.mainTable.draw();
                return true;
            }

            if (window.jQuery.fn.dataTable.isDataTable('#main-table')) {
                window.mainTable = window.jQuery('#main-table').DataTable();
                window.mainTable.draw();
                return true;
            }

            return false;
        }

        function applyFilter() {
            var dataTableApplied = false;
            if (filterEl) {
                dataTableApplied = ensureDataTableFilter();
            }
            if (!dataTableApplied) {
                applyPlainFilter();
            }
            refreshOwnerSourceCounts();
            if (currentViewMode === 'grid') {
                renderGridFromVisibleRows();
            }
        }

        function htmlEscape(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function collectVisibleRows() {
            var rows = tableEl.querySelectorAll('tbody tr');
            var items = [];
            rows.forEach(function (row) {
                if (row.classList.contains('fm-parent-row')) {
                    return;
                }

                if (!rowMatchesFilter(row)) {
                    return;
                }

                var display = window.getComputedStyle(row).display;
                if (display === 'none') {
                    return;
                }

                var nameCell = row.querySelector('td.fm-col-name .filename');
                if (!nameCell) {
                    return;
                }

                var nameLink = nameCell.querySelector('a');
                if (!nameLink) {
                    return;
                }

                var iconEl = nameLink.querySelector('i');
                var sizeCell = row.querySelector('td.fm-col-size');
                var modCell = row.querySelector('td.fm-col-modified');
                var ownerCell = row.querySelector('td.fm-col-owner');
                var actionsWrap = row.querySelector('td.fm-col-actions .inline-actions');
                var ownerSource = ownerCell ? String(ownerCell.getAttribute('data-owner-source') || 'system').toLowerCase() : 'system';

                items.push({
                    nameHtml: nameLink.outerHTML,
                    iconClass: iconEl ? iconEl.className : 'fa fa-file-o',
                    sizeText: sizeCell ? (sizeCell.textContent || '').trim() : '',
                    modText: modCell ? (modCell.textContent || '').trim() : '',
                    ownerHtml: ownerCell ? ownerCell.innerHTML : '',
                    ownerSource: ownerSource,
                    actionsHtml: actionsWrap ? actionsWrap.innerHTML : '',
                });
            });
            return items;
        }

        function renderGridFromVisibleRows() {
            if (!gridViewEl) {
                return;
            }

            var items = collectVisibleRows();
            if (!items.length) {
                gridViewEl.innerHTML = '<div class="alert alert-light border mb-0">Ziadne polozky pre aktualny filter.</div>';
                return;
            }

            var cards = items.map(function (item) {
                var ownerSourceBadge = item.ownerSource === 'app' ? '<span class="badge text-bg-primary">App</span>' : '<span class="badge text-bg-secondary">System</span>';
                return '<div class="card fm-grid-item">'
                    + '<div class="fm-grid-thumb"><i class="' + htmlEscape(item.iconClass) + '"></i></div>'
                    + '<div class="fm-grid-body">'
                    + '<div class="fm-grid-name">' + item.nameHtml + '</div>'
                    + '<div class="fm-grid-meta"><span>' + htmlEscape(item.sizeText) + '</span><span>' + htmlEscape(item.modText) + '</span></div>'
                    + '<div class="d-flex align-items-center justify-content-between mt-2"><div class="small">' + item.ownerHtml + '</div>' + ownerSourceBadge + '</div>'
                    + '</div>'
                    + '<div class="fm-grid-actions"><div class="inline-actions">' + item.actionsHtml + '</div></div>'
                    + '</div>';
            }).join('');

            gridViewEl.innerHTML = '<div class="fm-grid">' + cards + '</div>';
        }

        function openCreateNewItemModal() {
            if (!canCreateNewItem) {
                return;
            }

            var modalEl = document.getElementById('createNewItem');
            if (!modalEl) {
                return;
            }

            if (window.bootstrap && window.bootstrap.Modal) {
                window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
                return;
            }

            if (window.jQuery && window.jQuery.fn && typeof window.jQuery.fn.modal === 'function') {
                window.jQuery(modalEl).modal('show');
            }
        }

        function ensureFloatingPanel() {
            if (floatingPanelEl) {
                return;
            }

            floatingPanelEl = document.createElement('div');
            floatingPanelEl.id = 'fm-row-actions-float';
            floatingPanelEl.className = 'fm-row-actions-float hidden';
            floatingPanelEl.innerHTML = ''
                + '<div class="fm-row-actions-float__header">'
                + '  <span class="fm-row-actions-float__title"></span>'
                + '  <button type="button" class="btn btn-sm btn-outline-primary fm-row-actions-float__new" title="<?php echo fm_enc(lng('NewItem')); ?>" aria-label="<?php echo fm_enc(lng('NewItem')); ?>"><i class="fa fa-plus-square" aria-hidden="true"></i></button>'
                + '  <button type="button" class="btn-close btn-close-sm fm-row-actions-float__close" aria-label="Close"></button>'
                + '</div>'
                + '<div class="inline-actions fm-row-actions-float__actions"></div>';

            document.body.appendChild(floatingPanelEl);
            floatingPanelTitleEl = floatingPanelEl.querySelector('.fm-row-actions-float__title');
            floatingPanelActionsEl = floatingPanelEl.querySelector('.fm-row-actions-float__actions');

            var closeBtn = floatingPanelEl.querySelector('.fm-row-actions-float__close');
            var newBtn = floatingPanelEl.querySelector('.fm-row-actions-float__new');
            if (newBtn) {
                if (!canCreateNewItem) {
                    newBtn.classList.add('hidden');
                    newBtn.setAttribute('disabled', 'disabled');
                } else {
                    newBtn.addEventListener('click', function () {
                        openCreateNewItemModal();
                    });
                }
            }
            if (closeBtn) {
                closeBtn.addEventListener('click', function () {
                    hideFloatingPanel();
                });
            }

            floatingPanelEl.addEventListener('mouseenter', function () {
                if (hoverHideTimer) {
                    window.clearTimeout(hoverHideTimer);
                    hoverHideTimer = null;
                }
            });

            floatingPanelEl.addEventListener('mouseleave', function () {
                if (currentViewMode === 'list' && !isNarrowViewport()) {
                    scheduleHideFloatingPanel();
                }
            });
        }

        function hideFloatingPanel() {
            if (!floatingPanelEl) {
                return;
            }
            floatingPanelEl.classList.add('hidden');
            activeFloatingRow = null;
        }

        function scheduleShowFloatingPanel(row) {
            if (hoverHideTimer) {
                window.clearTimeout(hoverHideTimer);
                hoverHideTimer = null;
            }
            if (hoverShowTimer) {
                window.clearTimeout(hoverShowTimer);
            }
            hoverShowTimer = window.setTimeout(function () {
                showFloatingActionsForRow(row);
                hoverShowTimer = null;
            }, HOVER_SHOW_DELAY_MS);
        }

        function scheduleHideFloatingPanel() {
            if (hoverShowTimer) {
                window.clearTimeout(hoverShowTimer);
                hoverShowTimer = null;
            }
            if (hoverHideTimer) {
                window.clearTimeout(hoverHideTimer);
            }
            hoverHideTimer = window.setTimeout(function () {
                hideFloatingPanel();
                hoverHideTimer = null;
            }, HOVER_HIDE_DELAY_MS);
        }

        function isNarrowViewport() {
            return window.matchMedia && window.matchMedia('(max-width: 767.98px)').matches;
        }

        function positionFloatingPanel(row) {
            if (!floatingPanelEl || !row) {
                return;
            }

            if (isNarrowViewport()) {
                floatingPanelEl.style.top = 'auto';
                floatingPanelEl.style.bottom = '12px';
                floatingPanelEl.style.right = '10px';
                return;
            }

            var rect = row.getBoundingClientRect();
            var panelRect = floatingPanelEl.getBoundingClientRect();
            var top = window.scrollY + rect.top + (rect.height / 2) - (panelRect.height / 2);
            var minTop = window.scrollY + 10;
            var maxTop = window.scrollY + window.innerHeight - panelRect.height - 10;
            if (top < minTop) {
                top = minTop;
            }
            if (top > maxTop) {
                top = maxTop;
            }

            floatingPanelEl.style.top = Math.round(top) + 'px';
            floatingPanelEl.style.bottom = 'auto';
            floatingPanelEl.style.right = '12px';
        }

        function showFloatingActionsForRow(row) {
            if (currentViewMode !== 'list' || !row || row.classList.contains('fm-parent-row')) {
                return;
            }

            var actionWrap = row.querySelector('td.fm-col-actions .inline-actions');
            if (!actionWrap || !floatingPanelActionsEl || !floatingPanelTitleEl) {
                return;
            }

            var titleEl = row.querySelector('td.fm-col-name .filename a');
            var titleText = titleEl ? (titleEl.textContent || '').trim() : 'Akcie';
            floatingPanelTitleEl.textContent = titleText;
            floatingPanelActionsEl.innerHTML = actionWrap.innerHTML;
            floatingPanelEl.classList.remove('hidden');
            activeFloatingRow = row;
            positionFloatingPanel(row);
        }

        function bindFloatingRowActions() {
            ensureFloatingPanel();

            tableEl.addEventListener('mouseover', function (event) {
                if (currentViewMode !== 'list' || isNarrowViewport()) {
                    return;
                }
                var row = event.target.closest('tbody tr');
                if (!row || row === activeFloatingRow) {
                    return;
                }
                scheduleShowFloatingPanel(row);
            });

            tableEl.addEventListener('click', function (event) {
                if (currentViewMode !== 'list' || !isNarrowViewport()) {
                    return;
                }

                if (event.target.closest('a,button,input,label')) {
                    return;
                }

                var row = event.target.closest('tbody tr');
                if (!row || row.classList.contains('fm-parent-row')) {
                    return;
                }

                showFloatingActionsForRow(row);
            });

            if (tableWrapEl) {
                tableWrapEl.addEventListener('mouseenter', function () {
                    if (hoverHideTimer) {
                        window.clearTimeout(hoverHideTimer);
                        hoverHideTimer = null;
                    }
                });

                tableWrapEl.addEventListener('mouseleave', function () {
                    if (!isNarrowViewport()) {
                        scheduleHideFloatingPanel();
                    }
                });
            }

            window.addEventListener('scroll', function () {
                if (floatingPanelEl && !floatingPanelEl.classList.contains('hidden') && activeFloatingRow) {
                    positionFloatingPanel(activeFloatingRow);
                }
            }, { passive: true });

            window.addEventListener('resize', function () {
                if (floatingPanelEl && !floatingPanelEl.classList.contains('hidden') && activeFloatingRow) {
                    positionFloatingPanel(activeFloatingRow);
                }
            });
        }

        function setViewMode(mode) {
            currentViewMode = mode === 'grid' ? 'grid' : 'list';

            viewButtons.forEach(function (btn) {
                var btnMode = String(btn.getAttribute('data-view-mode') || 'list');
                var active = btnMode === currentViewMode;
                btn.classList.toggle('active', active);
            });

            if (tableWrapEl) {
                tableWrapEl.classList.toggle('hidden', currentViewMode === 'grid');
            }
            if (gridViewEl) {
                gridViewEl.classList.toggle('hidden', currentViewMode !== 'grid');
            }

            document.body.classList.toggle('fm-list-mode', currentViewMode === 'list');
            document.body.classList.toggle('fm-grid-mode', currentViewMode === 'grid');

            if (currentViewMode === 'grid') {
                if (hoverShowTimer) {
                    window.clearTimeout(hoverShowTimer);
                    hoverShowTimer = null;
                }
                if (hoverHideTimer) {
                    window.clearTimeout(hoverHideTimer);
                    hoverHideTimer = null;
                }
                hideFloatingPanel();
                renderGridFromVisibleRows();
            }
        }

        if (filterEl) {
            filterEl.addEventListener('change', applyFilter);
        }
        countBadgeEls.forEach(function (badge) {
            function applyTargetFilter() {
                var target = String(badge.getAttribute('data-owner-filter-target') || '').toLowerCase();
                if (!target || !filterEl) {
                    return;
                }
                filterEl.value = target;
                applyFilter();
            }

            badge.addEventListener('click', applyTargetFilter);
            badge.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    applyTargetFilter();
                }
            });
        });
        viewButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var mode = String(btn.getAttribute('data-view-mode') || 'list');
                setViewMode(mode);
            });
        });
        bindFloatingRowActions();
        refreshOwnerSourceCounts();
        window.setTimeout(function () {
            applyFilter();
            setViewMode('list');
        }, 0);
    })();
</script>

<?php if ($footerShowUserBadges): ?>
    <style>
        .fm-user-chat-badge.fm-chat-ringing {
            background-color: #dc3545 !important;
            color: #fff !important;
            animation: fm-chat-ring-blink 0.85s steps(2, jump-none) infinite;
        }

        @keyframes fm-chat-ring-blink {
            50% {
                opacity: 0.35;
            }
        }
    </style>

    <div class="modal fade" id="fm-chat-modal" tabindex="-1" aria-labelledby="fm-chat-modal-label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fm-chat-modal-label">Chat</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <div id="fm-chat-history" class="p-3" style="max-height: 420px; overflow-y: auto;"></div>
                </div>
                <div class="modal-footer">
                    <form id="fm-chat-form" class="w-100 d-flex gap-2 m-0">
                        <input type="text" id="fm-chat-input" class="form-control" maxlength="2000" placeholder="Write a message..." autocomplete="off">
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            var currentUser = <?php echo json_encode($footerLoggedUser); ?>;
            if (!currentUser) {
                return;
            }

            var modalEl = document.getElementById('fm-chat-modal');
            var historyEl = document.getElementById('fm-chat-history');
            var formEl = document.getElementById('fm-chat-form');
            var inputEl = document.getElementById('fm-chat-input');
            var titleEl = document.getElementById('fm-chat-modal-label');
            var tokenEl = document.querySelector('input[name="token"]');
            var badges = document.querySelectorAll('.fm-user-chat-badge[data-chat-user]');
            var unreadCountEls = document.querySelectorAll('.fm-chat-unread-count');
            var unreadBadgeEls = document.querySelectorAll('.fm-chat-unread-badge');

            if (!modalEl || !historyEl || !formEl || !inputEl || !titleEl || !tokenEl) {
                return;
            }

            var modal = null;
            var state = {
                peer: '',
                timer: null,
                inboxTimer: null,
                inboxInitialized: false,
                lastIncomingBySender: {},
                unreadBySender: {},
                lastReadBySender: {},
            };

            var readStateStorageKey = 'tfm-chat-read:' + currentUser;

            var badgeByUser = {};
            badges.forEach(function (badge) {
                var u = badge.getAttribute('data-chat-user') || '';
                if (u) {
                    badgeByUser[u] = badge;
                }
            });

            function loadReadState() {
                try {
                    var raw = window.localStorage ? window.localStorage.getItem(readStateStorageKey) : '';
                    if (!raw) {
                        return;
                    }
                    var data = JSON.parse(raw);
                    if (data && typeof data === 'object') {
                        state.lastReadBySender = data;
                    }
                } catch (e) {
                }
            }

            function saveReadState() {
                try {
                    if (window.localStorage) {
                        window.localStorage.setItem(readStateStorageKey, JSON.stringify(state.lastReadBySender));
                    }
                } catch (e) {
                }
            }

            function setUnreadCount(total) {
                unreadCountEls.forEach(function (el) {
                    el.textContent = String(total);
                });
                unreadBadgeEls.forEach(function (el) {
                    el.style.display = total > 0 ? '' : 'none';
                });
            }

            function recomputeUnreadCount() {
                var total = 0;
                Object.keys(state.unreadBySender).forEach(function (sender) {
                    if (state.unreadBySender[sender] > 0) {
                        total++;
                    }
                });
                setUnreadCount(total);
            }

            function markSenderRead(sender, id) {
                if (!sender || !id) {
                    return;
                }
                var readId = Number(state.lastReadBySender[sender] || 0);
                if (id > readId) {
                    state.lastReadBySender[sender] = id;
                    saveReadState();
                }
                delete state.unreadBySender[sender];
                recomputeUnreadCount();
            }

            function markBadgeRinging(user, ring) {
                if (!user || !badgeByUser[user]) {
                    return;
                }
                badgeByUser[user].classList[ring ? 'add' : 'remove']('fm-chat-ringing');
            }

            function showModal() {
                var hasBootstrap5Modal = !!(window.bootstrap && window.bootstrap.Modal);
                var hasJQueryModal = !!(window.jQuery && window.jQuery.fn && window.jQuery.fn.modal);

                if (hasBootstrap5Modal) {
                    if (!modal) {
                        modal = new window.bootstrap.Modal(modalEl);
                    }
                    modal.show();
                    return;
                }

                if (hasJQueryModal) {
                    window.jQuery(modalEl).modal('show');
                    return;
                }

                // Last-resort fallback when Bootstrap JS is not available.
                modalEl.style.display = 'block';
                modalEl.classList.add('show');
                modalEl.removeAttribute('aria-hidden');
            }

            function bindModalHidden(handler) {
                if (modalEl.addEventListener) {
                    modalEl.addEventListener('hidden.bs.modal', handler);
                }
                if (window.jQuery && window.jQuery.fn && window.jQuery.fn.modal) {
                    window.jQuery(modalEl).on('hidden.bs.modal', handler);
                }
            }

            function bindFallbackClose() {
                var closeEls = modalEl.querySelectorAll('[data-bs-dismiss="modal"], .btn-close');
                closeEls.forEach(function (closeEl) {
                    closeEl.addEventListener('click', function () {
                        modalEl.classList.remove('show');
                        modalEl.style.display = 'none';
                        modalEl.setAttribute('aria-hidden', 'true');
                        stopPolling();
                        clearPeerNotification(state.peer);
                        state.peer = '';
                        formEl.reset();
                    });
                });
            }

            function esc(value) {
                return String(value)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#39;');
            }

            function formatTime(ts) {
                if (!ts) {
                    return '';
                }
                return new Date(ts * 1000).toLocaleString();
            }

            function renderMessages(messages) {
                if (!Array.isArray(messages) || messages.length === 0) {
                    historyEl.innerHTML = '<div class="text-muted small p-2">No messages yet.</div>';
                    return;
                }

                var html = messages.map(function (msg) {
                    var mine = msg.sender === currentUser;
                    var align = mine ? 'justify-content-end' : 'justify-content-start';
                    var bubble = mine ? 'bg-primary text-white' : 'bg-light border';
                    return '<div class="d-flex ' + align + ' mb-2">'
                        + '<div class="rounded px-3 py-2 ' + bubble + '" style="max-width: 75%;">'
                        + '<div class="small fw-semibold mb-1">' + esc(msg.sender || '') + '</div>'
                        + '<div>' + esc(msg.message || '') + '</div>'
                        + '<div class="small opacity-75 mt-1">' + esc(formatTime(msg.created_at || 0)) + '</div>'
                        + '</div>'
                        + '</div>';
                }).join('');

                historyEl.innerHTML = html;
                historyEl.scrollTop = historyEl.scrollHeight;
            }

            function chatFetch() {
                if (!state.peer) {
                    return;
                }

                var url = new URL(window.location.href);
                url.searchParams.set('chat_action', 'fetch');
                url.searchParams.set('with', state.peer);

                fetch(url.toString(), {
                    credentials: 'same-origin'
                })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (!payload || payload.ok !== true || !payload.data) {
                            return;
                        }
                        var messages = payload.data.messages || [];
                        renderMessages(messages);

                        var maxIncomingId = 0;
                        messages.forEach(function (msg) {
                            if ((msg.sender || '') === state.peer) {
                                var mid = Number(msg.id || 0);
                                if (mid > maxIncomingId) {
                                    maxIncomingId = mid;
                                }
                            }
                        });
                        if (maxIncomingId > 0) {
                            markSenderRead(state.peer, maxIncomingId);
                        }
                    })
                    .catch(function () {
                    });
            }

            function chatSend(message) {
                var url = new URL(window.location.href);
                url.searchParams.set('chat_action', 'send');

                var body = new URLSearchParams();
                body.set('to', state.peer);
                body.set('message', message);
                body.set('token', tokenEl.value || '');

                return fetch(url.toString(), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    credentials: 'same-origin',
                    body: body.toString()
                })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (payload && payload.ok && payload.data) {
                            renderMessages(payload.data.messages || []);
                            return true;
                        }
                        return false;
                    })
                    .catch(function () {
                        return false;
                    });
            }

            function startPolling() {
                if (state.timer) {
                    window.clearInterval(state.timer);
                }
                state.timer = window.setInterval(chatFetch, 5000);
            }

            function stopPolling() {
                if (state.timer) {
                    window.clearInterval(state.timer);
                    state.timer = null;
                }
            }

            function pollInbox() {
                var url = new URL(window.location.href);
                url.searchParams.set('chat_action', 'inbox');

                fetch(url.toString(), {
                    credentials: 'same-origin'
                })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (!payload || payload.ok !== true || !payload.data || !Array.isArray(payload.data.inbox)) {
                            return;
                        }

                        var inbox = payload.data.inbox;
                        var shouldAutoOpenSender = '';
                        inbox.forEach(function (item) {
                            var sender = item && item.sender ? String(item.sender) : '';
                            var id = item && item.id ? Number(item.id) : 0;
                            if (!sender || !id || sender === currentUser) {
                                return;
                            }

                            var prev = Number(state.lastIncomingBySender[sender] || 0);
                            if (id > prev) {
                                state.lastIncomingBySender[sender] = id;

                                if (state.peer === sender) {
                                    chatFetch();
                                    markBadgeRinging(sender, false);
                                    markSenderRead(sender, id);
                                } else {
                                    if (state.inboxInitialized && !state.peer && !shouldAutoOpenSender) {
                                        shouldAutoOpenSender = sender;
                                    }
                                }
                            }

                            if (state.peer !== sender) {
                                var currentReadId = Number(state.lastReadBySender[sender] || 0);
                                if (id > currentReadId) {
                                    state.unreadBySender[sender] = id;
                                    markBadgeRinging(sender, true);
                                } else {
                                    delete state.unreadBySender[sender];
                                    markBadgeRinging(sender, false);
                                }
                            }
                        });

                        state.inboxInitialized = true;
                        recomputeUnreadCount();

                        if (shouldAutoOpenSender) {
                            state.peer = shouldAutoOpenSender;
                            titleEl.textContent = 'Chat with ' + shouldAutoOpenSender;
                            historyEl.innerHTML = '<div class="text-muted small p-2">Loading...</div>';
                            showModal();
                            chatFetch();
                            startPolling();
                        }
                    })
                    .catch(function () {
                    });
            }

            function startInboxPolling() {
                if (state.inboxTimer) {
                    window.clearInterval(state.inboxTimer);
                }
                pollInbox();
                state.inboxTimer = window.setInterval(pollInbox, 4000);
            }

            function clearPeerNotification(peer) {
                if (!peer) {
                    return;
                }
                markBadgeRinging(peer, false);
                var lastIncoming = Number(state.lastIncomingBySender[peer] || 0);
                if (lastIncoming > 0) {
                    markSenderRead(peer, lastIncoming);
                }
            }

            badges.forEach(function (badge) {
                badge.addEventListener('click', function () {
                    var peer = badge.getAttribute('data-chat-user') || '';
                    if (!peer || peer === currentUser) {
                        return;
                    }
                    state.peer = peer;
                    clearPeerNotification(peer);
                    titleEl.textContent = 'Chat with ' + peer;
                    historyEl.innerHTML = '<div class="text-muted small p-2">Loading...</div>';
                    showModal();
                    chatFetch();
                    startPolling();
                });
            });

            bindModalHidden(function () {
                stopPolling();
                clearPeerNotification(state.peer);
                state.peer = '';
                formEl.reset();
            });

            bindFallbackClose();

            formEl.addEventListener('submit', function (event) {
                event.preventDefault();
                var message = (inputEl.value || '').trim();
                if (!message || !state.peer) {
                    return;
                }

                chatSend(message).then(function (ok) {
                    if (ok) {
                        clearPeerNotification(state.peer);
                        inputEl.value = '';
                        inputEl.focus();
                    }
                });
            });

            loadReadState();
            setUnreadCount(0);
            startInboxPolling();
        })();
    </script>
<?php endif; ?>

<?php
